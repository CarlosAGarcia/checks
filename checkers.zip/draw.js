var draw = function(board,canvas) {	

    var boardSize = board.size(); // number of cells
    var boxSize = 400;  //in pixels
    var cellPixels = 400/boardSize;    //pixels in each cell
    var boardImg = $("<canvas>");
    var arrowImg = $("<canvas>").attr("class","overlay");
	
	rules = new Rules(board);
    boardObj = new Object();   
	var angle = 0;

    boardObj.checkers = [];
	
    for(i=0;i<boardSize;i++){
		boardObj.checkers[i] = [];
	}

    var getChecker = function(checker){
		//console.log(checker);
        var path;// = "graphics/" + checker.color + "-";
       		if (checker.color == "red"){
			if(checker.isKing){
				path = "url('red-king.png')";
			}else {
				path = "url('red-piece.png')";
			}
		}else {
			if(checker.isKing){
				path = "url('black-king.png')";
			} else {
				path = "url('black-piece.png')";
			}
			
		}

        var checkerImg = $("<div>").css('background-image', path)
                                    .css("background-size", "contain")                                 
                                    .css("width",cellPixels)
                                    .css("height",cellPixels)
									.attr('class',"overlay")
                                    .css("left",checker.col*cellPixels).css("top",checker.row*cellPixels);
        //console.log(checkerImg);
        return checkerImg;
    }

    boardObj.newBoard = function(){
     
		$($(canvas).find("canvas")).remove();
        boardImg.prop("width",boxSize).prop("height",boxSize).appendTo(canvas);
			
        arrowImg.css("left","0px").prop("width",boxSize).prop("height",boxSize).appendTo(canvas).css("z-index",2);          ///ADDDDDD AFTER

        ctx = boardImg[0].getContext('2d');

        ctx.fillStyle = "white"; //draws checkerboard
		var boxsize = cellPixels;
		for (var i = 0;i< 400;i++){	
		//increments the Y values
		//if statements to decide colour of box.
			for(var j = 0; j < 400; j++)
			{
				if((i+j)%2 === 0)
					ctx.fillStyle = "#FFFFFF"; 	
				else
					ctx.fillStyle = "#D3D3D3"; 		
										
				ctx.fillRect(i*boxsize,j*boxsize,boxsize,boxsize);	//draws the boxes
			}
		}
       

        boardImg.mousedown(function(event){
			
            var position = getPosition(boardImg,event);
            var coord = getCoord(position);
			var x = coord.row;
			var y = coord.col;
            var checkerImg = boardObj.checkers[x][y];

            checkerImg.checker = board.getCheckerAt(x,y);

            if(directionOf(whoseTurn) === directionOf(checkerImg.checker.color)) {
                var img = drag(checkerImg,y,x,position); 				
				
                boardImg.mousemove(function(event){
                    img.change(getPosition(boardImg,event));
                });
				
				
                boardImg.mouseup(function(event){
                  
                    var finalOffset = getPosition(boardImg,event);
                    var finalCoordinates = getCoord(finalOffset);
					boardImg.unbind("mousemove");
					
                    if(rules.makeMove(checkerImg.checker, directionOf(whoseTurn), 
						directionOf(checkerImg.checker.color), 
						finalCoordinates.row, finalCoordinates.col) === null){
                        img.resett();                    
                    }
                    img.done();
                    boardImg.unbind("mouseleave");
                    boardImg.unbind("mouseup");
                 });
				 
                 boardImg.mouseleave(function(event){
                    $(document).mouseup(function(event){boardImg.trigger("mouseup")});
                });
            }
        });
        
	var checkers =  board.getAllCheckers();
        //delete all the previous images.
        for(i=0;i<boardSize;i++){
			
            for(j=0;j<boardSize;j++){
                if(typeof boardObj.checkers[i][j] !== "undefined"){
					boardObj.checkers[i][j].remove();
					
                }
            }
        }
        
        for(i=0;i<boardSize;i++){
			//console.log("checkers 2nd for loop");
			boardObj.checkers[i] = [];
		}
        checkers.forEach(function(e){boardObj.checkers[e.row][e.col] = getChecker(e)});
		
		for(i=0;i<boardSize;i++){
			for(j=0;j<boardSize;j++){
                if(typeof boardObj.checkers[i][j] !== "undefined"){
					//console.log(boardObj.checkers[i][j]);
					boardObj.checkers[i][j].appendTo(canvas);
                }
            }
        }

    }


        //do some coalesence on the move of the mouse.

    var drag = function(input,col,row,mousepos,anim){          //   FOR DRAGGING
	
        
        var initialX = parseInt(input.css("left")) - mousepos.x;
		var initialY = parseInt(input.css("top"))  - mousepos.y;

        var x;
        var y;
        var timeLimit = 0 ;
	
        var dragging = (typeof anim === "undefined") ? 20 : anim;
        input.css("z-index",3);
		
		var dragFunc = {};
		
		//for draggin the checker 
		dragFunc.start = function(){			
            var cornerX = x  + initialX;			
            var cornerY = y  + initialY;
			console.log(cornerX,cornerY);
            input.animate({ "left": cornerX , "top":cornerY }, dragging);
         
        }
		
		/*		dragFunc.end = function(){			
            var cornerX = x  - initialX;			
            var cornerY = y  + initialY;
            input.animate({ "left": cornerX , "top":cornerY }, dragging);
         
        }
		*/
        dragFunc.resett = function(){          
		
			var x = col*cellPixels;
			var y = row*cellPixels;
			
            input.animate({ "left": x , "top":y }, dragging * 4 );
        }
/*		dragFunc.start2 = function(){			
            var cornerX = x  + initialX;			       
            input.animate({ "right": cornerX , "top":cornerY }, dragging);
         
        }
		*/
		
        dragFunc.change = function(offset){
			console.log("change func");
            x = offset.x;
            y = offset.y;
            if(timeLimit === 0){
            //move the cursor
            dragFunc.start();
            timeLimit = setTimeout(function(){
                    timeLimit = 0;
                    dragFunc.start();
                },50)
            }
        }


        dragFunc.done = function(){
            clearTimeout(timeLimit);
            input.css("z-index",1);
        }
        return dragFunc;
    }

    boardObj.updateBoard = function(completeBoard){
        var checkers = board.getAllCheckers();
        //delete all the previous images.
        for(i=0;i<boardSize;i++){
            for(j=0;j<boardSize;j++){
                if(typeof boardObj.checkers[i][j] !== "undefined"){
                    boardObj.checkers[i][j].remove();
                }
            }
        }
        boardObj.checkers = [];
        for(i=0;i<boardSize;i++){boardObj.checkers[i] = []};
        checkers.forEach(function(e){boardObj.checkers[e.row][e.col] = getChecker(e)});
        for(i=0;i<boardSize;i++){
            for(j=0;j<boardSize;j++){
                if(typeof boardObj.checkers[i][j] !== "undefined"){
                boardObj.checkers[i][j].appendTo(canvas);
                }
            }
        }
    }
	
	
    boardObj.add = function(event){boardObj.checkers[event.details.row][event.details.col] = getChecker(event.details.checker).appendTo(canvas);}

    boardObj.move = function(event){
		
		//console.log(event.details);	
		//sets up the mid points on the board to draw from and to
		centerFromWidth = (event.details.fromCol * cellPixels) + (cellPixels/2);
		centerFromHeight = (event.details.fromRow * cellPixels) + (cellPixels/2);
		centerToWidth = (event.details.toCol * cellPixels) + (cellPixels/2);
		centerToHeight = (event.details.toRow * cellPixels) + (cellPixels/2);
		
		//console.log(centerFromWidth, centerFromHeight,centerToWidth,centerToHeight); 
		var x = event.details.toCol*cellPixels;
		var y = event.details.toRow*cellPixels;
		var ctx = arrowImg[0].getContext('2d');
        var arwHead = (cellPixels / 5) * 3;
        var arwHeight = (cellPixels / 5) * 2;
		var angle = Math.atan((centerToHeight-centerFromHeight)/(centerToWidth - centerFromWidth));
		var length = Math.sqrt(Math.pow((centerFromWidth-centerToWidth),2)+Math.pow((centerFromHeight-centerToHeight),2))
		if ((centerToWidth - centerFromWidth) < 0) { 
			angle += Math.PI;
		}
		
		//set up
        ctx.strokeStyle = "yellow";
        ctx.fillStyle = "yellow";
        ctx.lineWidth=2;
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, arrowImg[0].width, arrowImg[0].height);
        ctx.translate(centerFromWidth,centerFromHeight);  
        ctx.rotate(angle);
        ctx.translate(-centerFromWidth,-centerFromHeight)
		
        //Begin drawing the arrow		
		ctx.beginPath();
		ctx.moveTo(centerFromWidth,centerFromHeight);
        ctx.lineTo(centerFromWidth + length,centerFromHeight);
		ctx.stroke(); 
		
		//draw triangle
		ctx.beginPath();
		ctx.moveTo(centerFromWidth + length,centerFromHeight);
        ctx.lineTo(centerFromWidth + length - arwHeight,centerFromHeight-arwHead/2);
        ctx.lineTo(centerFromWidth + length - arwHeight,centerFromHeight+arwHead/2);
        ctx.fill(); 
		
		//update the checkers
        boardObj.checkers[event.details.toRow][event.details.toCol] = boardObj.checkers[event.details.fromRow][event.details.fromCol];
        boardObj.checkers[event.details.fromRow][event.details.fromCol] = undefined;   
        boardObj.checkers[event.details.toRow][event.details.toCol].animate({ "left": x , "top":y }, 200 );
    }

    boardObj.remove = function(event){
		
        boardObj.checkers[event.details.row][event.details.col].detach();
        boardObj.checkers[event.details.row][event.details.col] = undefined;

    }

    var getPosition = function(object,e){
      if( typeof e.offsetX === "undefined"){
        xpos = e.pageX-object.offset().left;
        ypos = e.pageY-object.offset().top;
        }             
      else{ 
        xpos = e.offsetX;
        ypos = e.offsetY;
        }
      return {"x" : xpos, "y" : ypos};
    }

    var getCoord = function(input){
        var row = Math.floor(input.y/cellPixels);
        var col = Math.floor(input.x/cellPixels);
        return {"col" : col, "row" : row};
    }

    return boardObj;
}